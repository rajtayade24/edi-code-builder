export type RiskLevel = 'low' | 'moderate' | 'high';
export type SurgicalUrgency = 'Emergency' | 'Elective' | 'Urgent';

export interface PatientDemographics {
  id: string;
  mrn: string;
  name: string;
  age: number;
  sex: 'Male' | 'Female' | 'Other';
  bmi: number;
  scheduledProcedure: string;
  urgency: SurgicalUrgency;
  asaClass: string;
  roomNumber: string;
  admissionDate: string;
  attendingSurgeon: string;
  anesthesiologist: string;
}

export interface ComplicationRisk {
  id: string;
  name: string;
  percentage: number;
  riskLevel: RiskLevel;
  benchmarkAvg: number;
  description: string;
}

export interface ModelBranchStatus {
  id: 'bilstm' | 'gat' | 'biobert' | 'xgboost';
  name: string;
  shortCode: string;
  description: string;
  statusText: string;
  featuresProcessed: number | string;
  latencyMs: number;
  weightContribution: number;
  lastUpdate: string;
  keyInsights: string[];
}

export interface ShapDriver {
  id: string;
  featureName: string;
  category: 'vitals' | 'graph' | 'note' | 'lab';
  attributionPercent: number;
  currentValue: string;
  baselineRange: string;
  explanation: string;
  impactLevel: 'critical' | 'moderate' | 'favorable';
}

export interface GatNode {
  id: string;
  name: string;
  icdCode: string;
  category: 'Cardiovascular' | 'Renal' | 'Endocrine' | 'Pulmonary' | 'Metabolic' | 'Vascular';
  attentionWeight: number;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  connectsTo: string[];
  description: string;
  x?: number;
  y?: number;
}

export interface VitalTimePoint {
  time: string;
  map: number;
  hr: number;
  spo2: number;
  rr: number;
  lactate: number;
  baseExcess: number;
  isMapAlert?: boolean;
}

export interface InterventionSettings {
  fluidBolus: boolean;
  icuAdmission: boolean;
  targetHemoglobin: number;
  inotropicSupport: boolean;
  prophylacticAntibiotics: boolean;
}

export interface PatientProfile {
  id: string;
  mrn: string;
  demographics: PatientDemographics;
  baselineMortalityRate: number;
  complications: ComplicationRisk[];
  modelBranches: ModelBranchStatus[];
  shapDrivers: ShapDriver[];
  gatNodes: GatNode[];
  vitalsSeries: VitalTimePoint[];
  fhirPayload: Record<string, any>;
  clinicalNotesExcerpt: string;
  isCustomAdded?: boolean;
}

export interface AddPatientInput {
  name: string;
  mrn: string;
  age: number;
  sex: 'Male' | 'Female' | 'Other';
  bmi: number;
  scheduledProcedure: string;
  urgency: SurgicalUrgency;
  asaClass: string;
  attendingSurgeon: string;
  clinicalReport: string;
  creatinine: number;
  hemoglobin: number;
  albumin: number;
  map: number;
}
