import React from 'react';
import { Header } from './components/layout/Header';
import { Toolbar } from './components/layout/Toolbar';
import { HeroRiskSummary } from './components/dashboard/HeroRiskSummary';
import { ClinicalReportCard } from './components/dashboard/ClinicalReportCard';
import { ModelBranchesBar } from './components/dashboard/ModelBranchesBar';
import { ShapExplainability } from './components/dashboard/ShapExplainability';
import { ComorbidityGraph } from './components/dashboard/ComorbidityGraph';
import { TimeSeriesVitals } from './components/dashboard/TimeSeriesVitals';
import { WhatIfSimulator } from './components/dashboard/WhatIfSimulator';

import { AddPatientModal } from './components/modals/AddPatientModal';
import { HandoffPdfModal } from './components/modals/HandoffPdfModal';
import { AlertAttendingModal } from './components/modals/AlertAttendingModal';
import { FhirJsonModal } from './components/modals/FhirJsonModal';
import { ModelBranchDetailModal } from './components/modals/ModelBranchDetailModal';

export const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col font-sans selection:bg-teal-600 selection:text-white">
      {/* 1. Top Navigation & Patient Selector + Add Patient Button */}
      <Header />

      {/* Main Dashboard Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* 2. Demographics Banner & Big 30-Day Mortality Score Card */}
        <HeroRiskSummary />

        {/* 3. Ingested Clinical Report & AI Findings Card */}
        <ClinicalReportCard />

        {/* 4. 4-Branch Multi-Modal AI Status Bar */}
        <ModelBranchesBar />

        {/* 5. Clinical Drivers (SHAP) & Interactive Co-Morbidity Graph (GAT Visualizer) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6">
            <ShapExplainability />
          </div>
          <div className="lg:col-span-6">
            <ComorbidityGraph />
          </div>
        </div>

        {/* 6. Time-Series Vitals & Labs Signal Monitors */}
        <TimeSeriesVitals />

        {/* 7. Interactive Clinical Intervention Risk Simulator */}
        <WhatIfSimulator />

        {/* 8. Export & Handoff Action Toolbar */}
        <Toolbar />

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-8">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 text-center text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p>© 2026 SurgRisk-AI Command Center • Designed for Operating Rooms, Surgical Teams &amp; ICU Workstations</p>
          <div className="flex items-center gap-4 font-medium">
            <span>HIPAA Compliant</span>
            <span>MIMIC-IV Connected</span>
            <span>HL7 FHIR R4 Standard</span>
          </div>
        </div>
      </footer>

      {/* Interactive Modals */}
      <AddPatientModal />
      <HandoffPdfModal />
      <AlertAttendingModal />
      <FhirJsonModal />
      <ModelBranchDetailModal />
    </div>
  );
};

export default App;
