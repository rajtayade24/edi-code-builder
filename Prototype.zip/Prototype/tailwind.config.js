/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#eff6ff',
          100: '#dbeafe',
          600: '#2563eb',
          800: '#1e40af',
          900: '#1e3a8a', // Deep Clinical Navy
          950: '#172554',
        },
        teal: {
          50: '#f0fdfa',
          600: '#0d9488', // Precision Teal
          700: '#0f766e',
        },
        medical: {
          bg: '#F8FAFC',
          card: '#FFFFFF',
          border: '#E2E8F0',
          text: '#0F172A',
          muted: '#475569',
        },
        risk: {
          low: {
            bg: '#D1FAE5',
            text: '#065F46',
            accent: '#10B981',
          },
          moderate: {
            bg: '#FEF3C7',
            text: '#92400E',
            accent: '#F59E0B',
          },
          high: {
            bg: '#FEE2E2',
            text: '#991B1B',
            accent: '#EF4444',
          },
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'card': '0 1px 3px 0 rgb(0 0 0 / 0.05), 0 1px 2px -1px rgb(0 0 0 / 0.05)',
        'card-hover': '0 4px 6px -1px rgb(0 0 0 / 0.07), 0 2px 4px -2px rgb(0 0 0 / 0.05)',
        'clinical': '0 10px 25px -5px rgba(30, 58, 138, 0.08), 0 8px 10px -6px rgba(30, 58, 138, 0.04)',
      },
    },
  },
  plugins: [],
};
